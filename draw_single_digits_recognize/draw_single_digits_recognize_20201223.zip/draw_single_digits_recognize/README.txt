1. Start the service first 
2. Visit the index.html via browser 
3. Draw a single digit on the canvas
4. Either click on "Read", or it will automatically be recognized after 1 second without new stroke on the canvas.